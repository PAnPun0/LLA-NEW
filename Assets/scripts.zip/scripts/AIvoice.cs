using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIvoice : MonoBehaviour
{
    public AudioSource Jane;
    void Start()
    {
        Jane.enabled = true;
    }

}
